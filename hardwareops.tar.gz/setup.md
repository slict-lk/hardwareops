HardwareOps Optimizer — Final Windows Installer Package

End user runs one self-contained installer, clicks through the wizard, and gets a desktop icon. The application files are installed under Program Files; Node.js 20 and PostgreSQL 17 are installed as registered Windows programs.

Double-click  HardwareOps-Setup-1.0.0.exe   (~400 MB)
    │
    ├─ UAC prompt → Yes
    ├─ Welcome              → Next
    ├─ Install folder       → Next
    ├─ Desktop shortcut     → Next
    ├─ Ready to install     → Install
    │       (progress bar: ~3 min, no interaction)
    │         • Node.js 20 LTS       (silent)
    │         • PostgreSQL 17        (silent)
    │         • bundled node_modules (no network needed)
    │         • CREATE DATABASE + schema load
    │         • .env written with random DB password
    └─ Finish (launches app)

Repository layout
   
hardwareops/
├── package.json                 ← ES module, deps, start script
├── package-lock.json
├── server.js                    ← API
├── index.html                   ← application UI
├── db.sql                       ← unchanged
├── exe.js                       ← creates the self-contained installer
├── .gitignore
├── assets/
│   └── app.ico                  ← optional installer icon
└── installers/                  ← official runtime installers you provide
    ├── node-v20.18.0-x64.msi
    └── postgresql-17.2-1-windows-x64.exe 

## Building the Windows installer

Build on 64-bit Windows with Node.js, Inno Setup 6, and the project dependencies
installed (`npm ci`). Place the official Node.js 20.18.0 x64 MSI and PostgreSQL
17.2 x64 installer in `installers/` using the exact filenames shown above. The
installer provisions a fresh machine; an existing HardwareOps configuration
or PostgreSQL 17 service must be removed before installation. Run:

```powershell
node .\exe.js
```

The resulting `dist\HardwareOps-Setup-1.0.0.exe` bundles the application,
`node_modules`, and both runtime installers. The build script does not download
runtime installers; obtain them from their official distributors. At install
time, it installs Node.js and PostgreSQL, creates and initializes the local
`hardwareops` database, and writes the app's private database configuration.
The generated Owner login is recorded in a uniquely named
`HardwareOps-First-Login-*.txt` file in the installing user's Documents folder.

Everything the user never sees

    ❌ No terminal window when launching the app

    ❌ No npm or psql commands during installation

    ❌ No database password prompt

    ❌ No CORS errors, no port juggling, no localhost:4000 to remember

    ❌ No source files in the Start menu (application files are installed under Program Files)

The install is one file. The launch is one icon. The app is one browser tab. That is the entire end-user surface.