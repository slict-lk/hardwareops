# HardwareOps Optimizer

HardwareOps Optimizer is a browser-based operations dashboard for a hardware
retailer. It combines point-of-sale, stock, purchasing, credit, service, rental,
and sales analytics workflows with role-based access.

## Features

- Dashboard with inventory, sales, VAT, low-stock, purchase-order, and receivables
  summaries
- Point of sale, inventory management, purchase orders, and goods received notes
- Customer credit, invoices, services, rentals, and shrinkage tracking
- Sales analytics and GMROI reporting
- Master data for suppliers, items, categories, brands, locations, tax codes,
  units of measure, payment terms, and price tiers
- Role-based permissions for Owner, Manager, Cashier, Storekeeper, and
  Accountant accounts
- Email-and-password sign-in with expiring server-side sessions

## Requirements

- Node.js 18 or later
- PostgreSQL
- npm

## Setup

1. Install the Node.js dependencies:

   ```sh
   npm install
   ```

2. Create a PostgreSQL database and configure the connection in `.env`:

   ```dotenv
   DATABASE_URL=postgres://USER:PASSWORD@HOST:5432/DATABASE
   PGSSLMODE=disable
   PORT=4000
   AUTH_BOOTSTRAP_EMAIL=rick@store.lk
   AUTH_BOOTSTRAP_PASSWORD=replace-with-a-unique-password-of-at-least-12-characters
   ```

   For a PostgreSQL service that requires TLS, set `PGSSLMODE=require`.
   Keep `.env` private and do not commit database credentials or passwords.

3. Initialize the database schema and sample data if the database is new:

   ```sh
   psql "$DATABASE_URL" -f db.sql
   ```

   **Warning:** `db.sql` drops and recreates the application tables. Running it
   against an existing database deletes its current data.

4. Start the API:

   ```sh
   npm start
   ```

   The API listens on `http://localhost:4000` by default. On startup it adds
   the password-hash column and session table if they do not already exist.
   `AUTH_BOOTSTRAP_PASSWORD` sets the configured Owner account's password only
   when that account does not already have a password.

5. Serve `index.html` from a local web server and open it in a browser. For
   example, use VS Code Live Server on port 5500. The frontend expects the API
   at `http://localhost:4000`; deployments using another API URL can set
   `window.HARDWAREOPS_API` before the page's application script runs.

6. Sign in with the configured Owner email and password. The Owner can set
   passwords for other accounts in **Masters → Users**. Passwords must contain
   at least 12 characters.

## Project files

- `index.html` — application interface, styles, and browser-side API client
- `server.js` — Express API, PostgreSQL access, login, and session handling
- `db.sql` — PostgreSQL schema and sample data
- `package.json` — runtime dependencies and npm scripts

## Development

Run the API with:

```sh
npm start
```

There is currently no automated project test suite configured in `package.json`.
